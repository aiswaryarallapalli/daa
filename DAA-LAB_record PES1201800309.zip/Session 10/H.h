/*
"Can it be that this is he?
 Heavens, is it she?"
*/

void DistributionCountingSorting(int* A, int n);

void MergeSort(int* A, int n);