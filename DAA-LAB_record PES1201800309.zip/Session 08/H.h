/*
"Can it be that this is he?
 Heavens, is it she?"
*/

int count_components_dfs(int n, int A[n][n]);

void DFS(int v, int *visited, int n, int A[n][n]);

int count_components_bfs(int n, int A[n][n]);

void BFS(int v, int *visited, int n, int A[n][n]);